# netdisk

Upload photos taken by esp32 to Baidu cloud disk.

## Create app

https://pan.baidu.com/union/doc/fl0hhnulu


## Depend

- [netdisk](https://github.com/Xinyuan-LilyGO/netdisk)
