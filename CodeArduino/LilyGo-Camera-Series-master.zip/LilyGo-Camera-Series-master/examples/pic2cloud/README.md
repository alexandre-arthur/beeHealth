# pic2cloud

Upload photos taken by esp32 to bemfa cloud.

