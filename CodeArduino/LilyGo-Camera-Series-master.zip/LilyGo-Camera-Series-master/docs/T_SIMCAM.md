# T_SIMCAM

## PINMAP

|     Name      | T-Camera Plus  |
| :-----------: | :------------: |
|    DVP Y9     |       15       |
|    DVP Y8     |       16       |
|    DVP Y7     |       17       |
|    DVP Y6     |       12       |
|    DVP Y5     |       10       |
|    DVP Y4     |        8       |
|    DVP Y3     |        9       |
|    DVP Y2     |       11       |
|   DVP VSNC    |        6       |
|   DVP HREF    |        7       |
|   DVP PCLK    |       13       |
|    DVP PWD    |      N/A       |
|   DVP XCLK    |       14       |
|   DVP SIOD    |        4       |
|   DVP SIOC    |        5       |
|   DVP RESET   |       18       |
|    SD MISO    |       40       |
|    SD MOSI    |       38       |
|    SD SCLK    |       39       |
|     SD CS     |       47       |
|   mPCIE RST   |       48       |
|   mPCIE TX    |       45       |
|   mPCIE RX    |       46       |
|   mPCIE LED   |       21       |
|    MIC SCK    |       41       |
|    MIC WS     |       42       |
|   MIC DATA    |        2       |
